/*
 * app.h
 *
 *  Created on: 15 de out de 2018
 *      Author: marcelo
 */

#ifndef APP_H_
#define APP_H_

void app_loop(void);
void app_init(void);

#endif /* APP_H_ */
